package com.ek.wshopapp;

import android.os.Bundle;
import android.widget.Toast;

public class ShowMessageActivity extends MainActivity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.start);

	}
}
